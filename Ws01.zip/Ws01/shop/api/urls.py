from django.urls import path
from .views import Login, Registr, ListProduct, CreateProduct, DetailProduct,  UserCart, CrudCart, ListOrder, Logout

urlpatterns = [
    # auth
    path('login', Login),
    path('signup', Registr),
    path('logout', Logout),


    path('products', ListProduct),
    path("product", CreateProduct),
    path("product/<int:pk>", DetailProduct),

    path('cart', UserCart),
    path('cart/<int:pk>', CrudCart),

    path("order", ListOrder)
]