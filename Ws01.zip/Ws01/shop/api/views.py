from django.db.models import Sum
from django.shortcuts import render
from rest_framework import status
from rest_framework.authtoken.models import Token
from rest_framework.decorators import permission_classes, authentication_classes, api_view
from rest_framework.permissions import IsAdminUser, IsAuthenticated
from rest_framework.response import Response

from .serializers import LoginSerializer, RegistrSerializer, ProductSerializer, CartSerializer, OrderSerializer
from .authentication import BearerAuthentication
from .models import Product, Cart, Order


@api_view(["POST"])
def Login(request):
    serializer = LoginSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)
    user = serializer.validated_data['user']
    if not user:
        return Response({"error": {
            "code": 403,
            "message": "Ошибка логина"
        }}, status=status.HTTP_403_FORBIDDEN)
    token, created = Token.objects.get_or_create(user=user)
    return Response({"data": {"user_token": token.key}}, status=status.HTTP_200_OK)


@api_view(["POST"])
def Registr(request):
    serializer = RegistrSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)
    user = serializer.save()
    token = Token.objects.create(user=user)
    return Response({"data": {"user_token": token.key}}, status=status.HTTP_201_CREATED)


@api_view(["GET"])
@permission_classes([IsAuthenticated, ])
def Logout(request):
    request.user.auth_token.delete()
    return Response({
                            "body": {
                            "message": "logout"
                            }
                        }
                    )


@api_view(["GET"])
def ListProduct(request):
    products = Product.objects.all()
    serializer = ProductSerializer(products, many=True)
    return Response({"body": serializer.data})


@api_view(["POST"])
@permission_classes([IsAdminUser, ])
def CreateProduct(request):
    serializer = ProductSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)
    serializer.save()
    return Response({
                        "body": {
                            "id": serializer.data["id"],
                            "message": "Product added"
                                }
                    })


@api_view(["DELETE", "PATCH"])
@permission_classes([IsAdminUser, ])
def DetailProduct(request, **kwargs):
    try:
        pk = kwargs.get("pk", None)
        product = Product.objects.get(pk=pk)
    except:
        return Response({"error": {
            "code": 404,
            "message": "Не найдено"
        }}, status=status.HTTP_404_NOT_FOUND)
    if request.method == "PATCH":
        serializer = ProductSerializer(data=request.data, instance=product, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)
    if request.method == "DELETE":
        product.delete()
        return Response({
                            "body": {
                                 "message": "Product removed"
                                }
                            })


@api_view(["GET"])
@permission_classes([IsAuthenticated, ])
def UserCart(request):
    cart, created = Cart.objects.get_or_create(user=request.user)
    serializer = CartSerializer(cart)
    return Response({"body": serializer.data["products"]})


@api_view(["DELETE", "POST"])
@permission_classes([IsAuthenticated, ])
def CrudCart(request, **kwargs):
    try:
        pk = kwargs.get("pk", None)
        product = Product.objects.get(pk=pk)
    except:
        return Response({"error": {
            "code": 404,
            "message": "Не найдено"
        }}, status=status.HTTP_404_NOT_FOUND)
    cart, created = Cart.objects.get_or_create(user=request.user)
    if request.method == "POST":
        cart.products.add(product)
        cart.save()
        return Response({
                            "body": {
                                "message": "Product add to card"
                                }
                            })
    if request.method == "DELETE":
        cart.products.remove(product)
        cart.save()
        return Response({
                            "body": {
                                 "message": "Item removed from cart"
                                }
                            })


@api_view(["GET", "POST"])
@permission_classes([IsAuthenticated, ])
def ListOrder(request):
    if request.method == "GET":
        order = Order.objects.filter(user=request.user)
        serializer = OrderSerializer(order, many=True)
        return Response({"body": serializer.data})
    if request.method == "POST":
        try:
            cart = Cart.objects.get(user=request.user)
        except:
            return Response({"error": {
                                        "code": 422,
                                        "message": "Cart is empty"
                                        }}, status=status.HTTP_422_UNPROCESSABLE_ENTITY)
        order = Order(user=request.user)
        full = 0
        order.order_price = cart.products.all().aggregate(Sum('price'))["price__sum"]
        order.save()
        for product in cart.products.all():
            order.products.add(product)
        cart.delete()
        return Response({
                            "body": {
                                "order_id": 1,
                                "message": "Order is processed"
                            }}, status=status.HTTP_201_CREATED)